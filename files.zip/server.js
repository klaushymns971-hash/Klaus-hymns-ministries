// Klaus Hymns Ministries - USSD server (English + Twi)
// Works with aggregators that POST sessionId, phoneNumber, text (Africa's Talking style).
// Other aggregators (Hubtel, Arkesel...) use different field names: adjust the lines marked ADAPT.
//
// Setup:  npm init -y && npm i express
// Run:    node server.js
// Callback URL for your aggregator:  https://YOUR-DOMAIN/ussd

const express = require("express");
const fs = require("fs");
const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const CONTACT = "0XX XXX XXXX"; // <-- put your real number

const T = {
  en: {
    welcome: "Welcome to Klaus Hymns Ministries",
    menu: ["Give", "Prayer Request", "Share a Testimony", "Upcoming Events", "Contact Us"],
    giveTitle: "Give",
    giving: { 1: "Tithe", 2: "Offering", 3: "Seed" },
    amount: "Enter amount in GHS:",
    confirm: (what, amt) => `Confirm ${what} of GHS ${amt}\n1. Confirm\n2. Cancel`,
    momo: "Check your phone and approve the Mobile Money prompt. God bless you!",
    cancelled: "Cancelled. God bless you.",
    prayerAsk: "Enter your prayer request (short):",
    prayerDone: "Thank you. We are praying with you.",
    testAsk: "Enter your testimony (short):",
    testDone: "Glory to God! Thank you for sharing.",
    events:
      "Festival of Testimonies\n29-30 Oct\nWith Major Sam & Rev Klaus Hymns\n\nWeekly services: add times here",
    contact: (c) => `Klaus Hymns Ministries\nCall/WhatsApp: ${c}`,
    invalid: "Invalid choice. Please dial again.",
    badAmount: "Invalid amount. Please dial again.",
    back: "0. Back",
  },
  tw: {
    welcome: "Akwaaba bra Klaus Hymns Ministries",
    menu: ["Ma (Give)", "Mpaebɔ Abisadeɛ", "Kyerɛ Adansedie", "Nhyiam a ɛreba", "Frɛ Yɛn"],
    giveTitle: "Ma",
    giving: { 1: "Du mu baako (Tithe)", 2: "Afɔrebɔ (Offering)", 3: "Aba (Seed)" },
    amount: "Hyɛ sika dodoɔ (GHS):",
    confirm: (what, amt) => `Si so: ${what} - GHS ${amt}\n1. Si so\n2. Gyae`,
    momo: "Hwɛ wo fon so na gye MoMo no tom. Onyankopɔn nhyira wo!",
    cancelled: "Wagyae. Onyankopɔn nhyira wo.",
    prayerAsk: "Kyerɛw wo mpaebɔ abisadeɛ (tiawa):",
    prayerDone: "Meda wo ase. Yɛrebɔ mpae ama wo.",
    testAsk: "Kyerɛw wo adansedie (tiawa):",
    testDone: "Onyankopɔn nya animuonyam! Meda wo ase.",
    events:
      "Adansedie Afahyɛ (Festival of Testimonies)\n29-30 Oct\nMajor Sam ne Rev Klaus Hymns\n\nAkwanhyia: fa mmerɛ hyɛ ha",
    contact: (c) => `Klaus Hymns Ministries\nFrɛ/WhatsApp: ${c}`,
    invalid: "Woapaw deɛ ɛnyɛ. San frɛ bio.",
    badAmount: "Sika dodoɔ no nteɛ. San frɛ bio.",
    back: "0. San kɔ akyi",
  },
};

function save(type, phone, data) {
  const line = JSON.stringify({ time: new Date().toISOString(), type, phone, data }) + "\n";
  fs.appendFileSync("submissions.jsonl", line);
}

// Replace with your MoMo provider's API (Hubtel, Paystack, etc.)
async function requestMoMoPayment(phone, amount, purpose) {
  console.log(`MoMo prompt -> ${phone}: GHS ${amount} for ${purpose}`);
  save("giving", phone, { amount, purpose });
  return true;
}

app.post("/ussd", async (req, res) => {
  const phone = req.body.phoneNumber; // ADAPT
  const text = req.body.text || ""; // ADAPT

  const all = text === "" ? [] : text.split("*");
  let reply;

  // Step 0: choose language
  if (all.length === 0) {
    reply = "CON Select language / Paw kasa\n1. English\n2. Twi";
  } else if (all[0] !== "1" && all[0] !== "2") {
    reply = "END Invalid choice / Woapaw deɛ ɛnyɛ";
  } else {
    const t = T[all[0] === "1" ? "en" : "tw"];

    // 0 = back, 00 = home (main menu)
    const parts = [];
    for (const p of all.slice(1)) {
      if (p === "00") parts.length = 0;
      else if (p === "0") parts.pop();
      else parts.push(p);
    }
    const [a, b, c, d] = parts;

    if (parts.length === 0) {
      reply = `CON ${t.welcome}\n` + t.menu.map((m, i) => `${i + 1}. ${m}`).join("\n");
    } else if (a === "1") {
      if (!b)
        reply = `CON ${t.giveTitle}\n1. ${t.giving[1]}\n2. ${t.giving[2]}\n3. ${t.giving[3]}\n${t.back}`;
      else if (!t.giving[b]) reply = `END ${t.invalid}`;
      else if (!c) reply = `CON ${t.giving[b]}\n${t.amount}\n${t.back}`;
      else if (!(Number(c) > 0)) reply = `END ${t.badAmount}`;
      else if (!d) reply = `CON ${t.confirm(t.giving[b], Number(c).toFixed(2))}`;
      else if (d === "1") {
        await requestMoMoPayment(phone, Number(c), t.giving[b]);
        reply = `END ${t.momo}`;
      } else reply = `END ${t.cancelled}`;
    } else if (a === "2") {
      if (!b) reply = `CON ${t.prayerAsk}`;
      else {
        save("prayer", phone, b);
        reply = `END ${t.prayerDone}`;
      }
    } else if (a === "3") {
      if (!b) reply = `CON ${t.testAsk}`;
      else {
        save("testimony", phone, b);
        reply = `END ${t.testDone}`;
      }
    } else if (a === "4") {
      reply = `END ${t.events}`;
    } else if (a === "5") {
      reply = `END ${t.contact(CONTACT)}`;
    } else {
      reply = `END ${t.invalid}`;
    }
  }

  res.set("Content-Type", "text/plain").send(reply);
});

app.listen(process.env.PORT || 3000, () => console.log("USSD server running"));
