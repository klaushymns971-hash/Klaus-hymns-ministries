# Klaus Hymns Ministries USSD (English + Twi)

## Put it online (Render, free tier works for testing)
1. Create a free account at github.com and make a new repository.
2. Upload these 3 files: server.js, package.json, render.yaml.
3. Create a free account at render.com > New > Web Service > connect the repository.
4. Build command: npm install   Start command: npm start
5. When it finishes, Render gives you a link like https://klaushymns-ussd.onrender.com
6. Your callback URL is that link + /ussd  (https://klaushymns-ussd.onrender.com/ussd)

## Get the code
1. Create an account with Hubtel or Africa's Talking.
2. Request a shared USSD code for "Klaus Hymns Ministries".
3. Give them your callback URL. They tell you which code is free and assign it.

## Before going live
- Put your real phone number in server.js (CONTACT).
- Add weekly service times in the events text.
- Connect requestMoMoPayment to your payment provider.
- Hubtel, Arkesel and Africa's Talking send slightly different field names. Tell Claude which one you chose and it will be adjusted.
